export async function GET() {
    return Response.json({
        message: "Hello Server"
    })
}