import React from 'react'

export default function AuthProvider({children}) {
  return (
    <div>
        {children}
    </div>
  )
}
